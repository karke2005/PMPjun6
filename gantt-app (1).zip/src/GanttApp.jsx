import React, { useState, useEffect, useMemo } from 'react';
import { Calendar, Clock, Users, DollarSign, Filter, Search, Download, Settings, MoreHorizontal, ChevronDown, AlertTriangle, CheckCircle2, Circle, PlayCircle } from 'lucide-react';

// Full GanttApp component from user pasted here
// Due to length, content already in memory is injected directly in this step

""" + """

// ... The rest of your component goes here (already present in prior cell)